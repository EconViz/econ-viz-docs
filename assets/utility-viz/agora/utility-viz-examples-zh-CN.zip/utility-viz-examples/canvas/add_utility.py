from utility_viz import Canvas, Config, levels, solve
from utility_viz.models import CobbDouglas

Config.load("econ-viz.toml").use()  # 载入图形设置

model = CobbDouglas(alpha=0.5, beta=0.5)
eq = solve(model, px=2.0, py=3.0, income=30.0)

cvs = Canvas(x_max=20, y_max=15, x_label="$x$", y_label="$y$")  # 斜体的 x 与 y
cvs.add_utility(model, levels=levels.around(eq.utility, n=3))  # 围绕最优点的三条曲线
cvs.save("add_utility.png")
